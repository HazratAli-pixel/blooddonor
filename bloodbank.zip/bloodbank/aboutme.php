
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>BloodBank & Donor Management System</title>
</head>

<body>

<?php include('header.php');?>

<style>
img {
  display: block;
  margin-left: auto;
  margin-right: auto;
  border: 10px solid #555;
}
    .btnstyle {
		  border: 5px outset red;
		  background-color: lightblue;    
		  text-align: center;
		}
.button{
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 16px 110px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 6px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button1 {
  background-color: white; 
  color: black; 
  border: 2px solid #4CAF50;
  border-radius: 12px;
}

.button1:hover {
  background-color: #4CAF50;
  color: white;
}
</style>
<div class="btnstyle">
</br>
</br>

	<img src="pic/ali.jpg" class = "center" alt="Hazrat Ali" width="380" height="450">
	<h1 style = "color : green;">Md. Hazrat Ali</h1>
	<h1 style = "color : green;">Daffodil Internatioal University</h1> <br/>
	
	<div>
	<form action ="http://facebook.com/alivai2" >
	<button class="button button1">facebook</button></form>
	
	<form action ="mailto:hazrat369ali@gmail.com" >
	<button class="button button1">E-mail</button></form></div>
	<br/><br/>
	<br/>
</div>
	<?php include('footer.php');?>
</body>


</html>



