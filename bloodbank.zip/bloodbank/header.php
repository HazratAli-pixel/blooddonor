<!DOCTYPE html>
<html lang="en">
<style>
body {font-family: Arial, Helvetica, sans-serif;}

.navbar {
  width: 100%;
  background-color: #555;
  overflow: auto;
}

.navbar a {
  float: left;
  padding: 12px;
  color: white;
  text-decoration: none;
  font-size: 17px;
}

.navbar a:hover {
  background-color: #055;
  
}

.active {
  background-color: #4CAF50;
}

</style>
<body>



<div class="navbar">
 <a class="active" href="index.php">BloodBank & Donor Management System</a>

  <a href="wbcdonor.php"> Why Became Donor</a> 

  <a href="becomedonar.php"> Became a Donor</a> 
  <a href="showdata.php">Search</a> 
  <a href="updateinfo.php"> Update Info</a>
  <a href=""> Ask</a>
  <a href="aboutme.php"> About Me</a>
</div>
</body>
</html> 