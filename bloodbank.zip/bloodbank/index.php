<?php
include('config.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
  
    <title>Blood Bank & Donor Management System</title>

</head>
<style>
img {
  display: block;
  margin-left: auto;
  margin-right: auto;
}
.cen {
	text-align : center;
	color : black;
	
}
.btnstyle {
		  border: 5px outset red;
		  background-color: lightblue;    
		  text-align: center;
		}
</style>

<body>

<?php include('header.php');?>
 <div class = "btnstyle">
	<img src = "pic/img1.jpg" class = "center" width="100%" height="330">
		<br/>
		 <div class = "cen">
         <h2 ><u>Blood Bank & Donor Management System</u></h2>
         <p> In this site, you can</p>                           

<p>Search Blood</p>
<p>Became a Donor</p>
<p>You can ask any blood related problems</p>           
                <p><b>"A healthy diet helps ensure a successful blood donation, and also makes you feel better! Check out the following recommended foods to eat prior to your donation."</b></p>
</div>
</br>
</br>
</br>
</br>
</br>
</br>
</div>
<?php 
include('footer.php');

?>
</body>

</html>
