
<style>
body {font-family: Arial, Helvetica, sans-serif;}

.navbar {
  width: 100%;
  background-color: #555;
  overflow: auto;
}
.navbar a {
  float: left;
  padding: 12px;
  color: white;
  text-decoration: none;
  font-size: 17px;
}
.cen2 {
	text-align : center;
	color : white;
</style>
<body>
  <footer class="navbar">
            <p class="cen2">Copyright &copy; Blood Bank(Ali)</p>
    </footer>
</body>



  
