 <header>
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                
            </ol>
            <div class="carousel-inner" role="listbox">
                <!-- Slide One - Set the background image for this slide in the line below -->

                <div class="carousel-item active" style="background-image: url('images/banner1.jpg')">
                    <div class="carousel-caption d-none d-md-block">
                       
					<q><h2>We make a living by what we get. We make a life by what we give</h2></q>
					<p class="author">– Winston Churchill</p>
	
	
                    </div>
                </div>
                
				<!-- Slide Two - Set the background image for this slide in the line below -->
                <div class="carousel-item" style="background-image: url('images/banner2.jpg')">
                    <div class="carousel-caption d-none d-md-block"> <q style = "color : black;">
					<h2><b>Never lose the opportunity for blood donation as it always chose someone special.</b></h2></q>
                    </div>
                </div>
                
				<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
				</a>
				<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
				</a>
				</div>
		
					<div class="slideshow-container">


			<!-- Next/prev buttons -->
			<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
			<a class="next" onclick="plusSlides(1)">&#10095;</a>
		</div>

		<!-- Dots/bullets/indicators -->
		<div class="dot-container">
		<span class="dot" onclick="currentSlide(1)"></span>
		<span class="dot" onclick="currentSlide(2)"></span>
		<span class="dot" onclick="currentSlide(3)"></span>
		</div>
		
	
</header>

