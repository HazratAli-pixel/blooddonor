  
  
  <footer class="py-3 bg-inverse">
        <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; BloodBank & Donor Management System 2020 (Hazrat Ali)</p>
	
        </div>
		
		<div class="container">
            <a  href = 'admin/index.php' style = "text-indent : 5em;">Admin</a>
        </div>
		
		
		
		
        <!-- /.container -->
    </footer>