
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BloodBank & Donor Management System</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/modern-business.css" rel="stylesheet">


</head>

<body>

<?php include('includes/header.php');?>

<head>
	<meta charset = "UTF-8">
	<title></title>
</head>

<style>
img {
  display: block;
  margin-left: auto;
  margin-right: auto;
}
.button{
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 16px 910px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 6px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button1 {
  background-color: white; 
  color: black; 
  border: 2px solid #4CAF50;
  border-radius: 12px;
}

.button1:hover {
  background-color: #4CAF50;
  color: white;
}
</style>

<br/>
<div>
	<img src="images/ali.jpg" class = "center" alt="Hazrat Ali" width="380" height="450">
	<h1 style = "text-align : center; color : green;">Md. Hazra Ali</h1> <br/>
	<h1 style = "text-align : center; color : green;">Update comming soon.............</h1> <br/>
	<button class="button button1"><a  href ="https://facebook.com/alivai2" ><b>facebook</b></a></button>
	
</div>



	
		
            
			
<br/>
	<?php include('includes/footer.php');?>
</body>


</html>



